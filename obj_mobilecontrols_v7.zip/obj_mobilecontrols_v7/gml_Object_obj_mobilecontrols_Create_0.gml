persistent = true
depth = -99999
btn_count = 16
max_touches = 5
// the texture sheet may be set as this object's own sprite; remember it, then clear it
// so the engine does not auto-draw the whole sheet at the top-left of the screen
sheet_spr = asset_get_index("spr_mobilecontrols")
if (sheet_spr < 0)
    sheet_spr = sprite_index
sprite_index = -1
// ctrl_mode: 0 = empty, 1 = arrows, 2 = joystick, 3 = floating joystick
ctrl_mode = 1
edit_mode = 0
drag_btn = -1
drag_dev = -1
joy_dev = -1
joy_ox = 0
joy_oy = 0
joy_l = 0
joy_r = 0
joy_u = 0
joy_d = 0
dyn_x = 0
dyn_y = 0
gw = display_get_gui_width()
gh = display_get_gui_height()

// joystick stick sprite (on the sheet)
joy_sx = 640
joy_sy = 0
joy_px = 683
joy_py = 0
joy_sw = 41
joy_sh = 41

// left
btn_sx[0] = 842
btn_sy[0] = 0
btn_px[0] = 871
btn_py[0] = 0
btn_sw[0] = 27
btn_sh[0] = 29
btn_nx[0] = 0.101
btn_ny[0] = 0.8
btn_w[0] = 0.112
btn_mode[0] = 0
btn_key[0] = 37
btn_edit_only[0] = 0
btn_vis[0] = 2
btn_dx[0] = btn_nx[0]
btn_dy[0] = btn_ny[0]

// right
btn_sx[1] = 900
btn_sy[1] = 0
btn_px[1] = 929
btn_py[1] = 0
btn_sw[1] = 27
btn_sh[1] = 29
btn_nx[1] = 0.242
btn_ny[1] = 0.8
btn_w[1] = 0.112
btn_mode[1] = 0
btn_key[1] = 39
btn_edit_only[1] = 0
btn_vis[1] = 2
btn_dx[1] = btn_nx[1]
btn_dy[1] = btn_ny[1]

// up
btn_sx[2] = 958
btn_sy[2] = 0
btn_px[2] = 987
btn_py[2] = 0
btn_sw[2] = 27
btn_sh[2] = 29
btn_nx[2] = 0.898
btn_ny[2] = 0.597
btn_w[2] = 0.112
btn_mode[2] = 0
btn_key[2] = 38
btn_edit_only[2] = 0
btn_vis[2] = 2
btn_dx[2] = btn_nx[2]
btn_dy[2] = btn_ny[2]

// down
btn_sx[3] = 784
btn_sy[3] = 0
btn_px[3] = 813
btn_py[3] = 0
btn_sw[3] = 27
btn_sh[3] = 29
btn_nx[3] = 0.898
btn_ny[3] = 0.823
btn_w[3] = 0.112
btn_mode[3] = 0
btn_key[3] = 40
btn_edit_only[3] = 0
btn_vis[3] = 2
btn_dx[3] = btn_nx[3]
btn_dy[3] = btn_ny[3]

// z
btn_sx[4] = 58
btn_sy[4] = 102
btn_px[4] = 87
btn_py[4] = 102
btn_sw[4] = 27
btn_sh[4] = 29
btn_nx[4] = 0.812
btn_ny[4] = 0.394
btn_w[4] = 0.096
btn_mode[4] = 0
btn_key[4] = ord("Z")
btn_edit_only[4] = 0
btn_vis[4] = 14
btn_dx[4] = btn_nx[4]
btn_dy[4] = btn_ny[4]
btn_ax[4] = 0.725
btn_ay[4] = 0.802
btn_dax[4] = 0.725
btn_day[4] = 0.802

// x
btn_sx[5] = 0
btn_sy[5] = 102
btn_px[5] = 29
btn_py[5] = 102
btn_sw[5] = 27
btn_sh[5] = 29
btn_nx[5] = 0.939
btn_ny[5] = 0.394
btn_w[5] = 0.096
btn_mode[5] = 0
btn_key[5] = ord("X")
btn_edit_only[5] = 0
btn_vis[5] = 14
btn_dx[5] = btn_nx[5]
btn_dy[5] = btn_ny[5]
btn_ax[5] = 0.825
btn_ay[5] = 0.721
btn_dax[5] = 0.825
btn_day[5] = 0.721

// c
btn_sx[6] = 726
btn_sy[6] = 0
btn_px[6] = 755
btn_py[6] = 0
btn_sw[6] = 27
btn_sh[6] = 29
btn_nx[6] = 0.876
btn_ny[6] = 0.215
btn_w[6] = 0.096
btn_mode[6] = 0
btn_key[6] = ord("C")
btn_edit_only[6] = 0
btn_vis[6] = 14
btn_dx[6] = btn_nx[6]
btn_dy[6] = btn_ny[6]
btn_ax[6] = 0.925
btn_ay[6] = 0.64
btn_dax[6] = 0.925
btn_day[6] = 0.64

// f2
btn_sx[7] = 636
btn_sy[7] = 102
btn_px[7] = 688
btn_py[7] = 102
btn_sw[7] = 50
btn_sh[7] = 25
btn_nx[7] = 0.962
btn_ny[7] = 0.08
btn_w[7] = 0.066
btn_mode[7] = 1
btn_key[7] = 113
btn_edit_only[7] = 0
btn_vis[7] = 15
btn_dx[7] = btn_nx[7]
btn_dy[7] = btn_ny[7]

// enter
btn_sx[8] = 0
btn_sy[8] = 160
btn_px[8] = 52
btn_py[8] = 160
btn_sw[8] = 50
btn_sh[8] = 25
btn_nx[8] = 0.962
btn_ny[8] = 0.14
btn_w[8] = 0.066
btn_mode[8] = 1
btn_key[8] = 13
btn_edit_only[8] = 0
btn_vis[8] = 15
btn_dx[8] = btn_nx[8]
btn_dy[8] = btn_ny[8]

// +fps
btn_sx[9] = 116
btn_sy[9] = 102
btn_px[9] = 168
btn_py[9] = 102
btn_sw[9] = 50
btn_sh[9] = 25
btn_nx[9] = 0.962
btn_ny[9] = 0.2
btn_w[9] = 0.066
btn_mode[9] = 2
btn_key[9] = 8
btn_edit_only[9] = 0
btn_vis[9] = 15
btn_dx[9] = btn_nx[9]
btn_dy[9] = btn_ny[9]

// -fps
btn_sx[10] = 220
btn_sy[10] = 102
btn_px[10] = 272
btn_py[10] = 102
btn_sw[10] = 50
btn_sh[10] = 25
btn_nx[10] = 0.962
btn_ny[10] = 0.26
btn_w[10] = 0.066
btn_mode[10] = 2
btn_key[10] = 9
btn_edit_only[10] = 0
btn_vis[10] = 15
btn_dx[10] = btn_nx[10]
btn_dy[10] = btn_ny[10]

// redact
btn_sx[11] = 948
btn_sy[11] = 102
btn_px[11] = 0
btn_py[11] = 133
btn_sw[11] = 50
btn_sh[11] = 25
btn_nx[11] = 0.962
btn_ny[11] = 0.322
btn_w[11] = 0.066
btn_mode[11] = 2
btn_key[11] = 4
btn_edit_only[11] = 0
btn_vis[11] = 15
btn_dx[11] = btn_nx[11]
btn_dy[11] = btn_ny[11]

// save
btn_sx[12] = 156
btn_sy[12] = 133
btn_px[12] = 208
btn_py[12] = 133
btn_sw[12] = 50
btn_sh[12] = 25
btn_nx[12] = 0.45
btn_ny[12] = 0.9
btn_w[12] = 0.066
btn_mode[12] = 2
btn_key[12] = 5
btn_edit_only[12] = 1
btn_vis[12] = 15
btn_dx[12] = btn_nx[12]
btn_dy[12] = btn_ny[12]

// reset
btn_sx[13] = 52
btn_sy[13] = 133
btn_px[13] = 104
btn_py[13] = 133
btn_sw[13] = 50
btn_sh[13] = 25
btn_nx[13] = 0.55
btn_ny[13] = 0.9
btn_w[13] = 0.066
btn_mode[13] = 2
btn_key[13] = 6
btn_edit_only[13] = 1
btn_vis[13] = 15
btn_dx[13] = btn_nx[13]
btn_dy[13] = btn_ny[13]

// joystick
btn_sx[14] = 102
btn_sy[14] = 0
btn_px[14] = 163
btn_py[14] = 0
btn_sw[14] = 59
btn_sh[14] = 59
btn_nx[14] = 0.153
btn_ny[14] = 0.724
btn_w[14] = 0.188
btn_mode[14] = 3
btn_key[14] = 0
btn_edit_only[14] = 0
btn_vis[14] = 12
btn_dx[14] = btn_nx[14]
btn_dy[14] = btn_ny[14]

// mode
btn_sx[15] = 260
btn_sy[15] = 133
btn_px[15] = 281
btn_py[15] = 133
btn_sw[15] = 19
btn_sh[15] = 24
btn_nx[15] = 0.027
btn_ny[15] = 0.1
btn_w[15] = 0.044
btn_mode[15] = 2
btn_key[15] = 7
btn_edit_only[15] = 0
btn_vis[15] = 15
btn_dx[15] = btn_nx[15]
btn_dy[15] = btn_ny[15]

for (i = 0; i < btn_count; i++)
{
    btn_down[i] = 0
    btn_was[i] = 0
    btn_show[i] = 0
}
// load saved layout
ini_open("mobilecontrols.ini")
for (i = 0; i < btn_count; i++)
{
    btn_nx[i] = ini_read_real("layout", string(i) + "x", btn_nx[i])
    btn_ny[i] = ini_read_real("layout", string(i) + "y", btn_ny[i])
}
for (i = 4; i <= 6; i++)
{
    btn_ax[i] = ini_read_real("alt", string(i) + "x", btn_ax[i])
    btn_ay[i] = ini_read_real("alt", string(i) + "y", btn_ay[i])
}
ctrl_mode = ini_read_real("settings", "mode", 1)
ini_close()
// Z, X and C use their second layout in the joystick modes
if (ctrl_mode >= 2)
{
    for (i = 4; i <= 6; i++)
    {
        t = btn_nx[i]
        btn_nx[i] = btn_ax[i]
        btn_ax[i] = t
        t = btn_ny[i]
        btn_ny[i] = btn_ay[i]
        btn_ay[i] = t
    }
}
