// Draw GUI event: joystick stick is rendered behind its base in fixed mode.
for (i = 0; i < btn_count; i++)
{
    if (btn_show[i] == 0)
        continue

    bw = btn_w[i] * gw
    bh = bw * btn_sh[i] / btn_sw[i]
    cx = btn_nx[i] * gw
    cy = btn_ny[i] * gh

    if (btn_mode[i] == 3 && ctrl_mode == 3)
    {
        // Floating joystick only exists while its finger is held.
        if (joy_dev == -1)
            continue
        cx = dyn_x
        cy = dyn_y
    }

    a = 0.6
    if (btn_down[i] == 1)
        a = 0.95

    if (sheet_spr >= 0)
    {
        // Fixed joystick (mode 2): draw the base first, then the LARGE ball
        // on top. Always use joy_sx/joy_sy for this mode; joy_px/joy_py
        // contains the small alternate ball graphic.
        if (btn_mode[i] == 3 && ctrl_mode == 2)
        {
            sx = btn_sx[i]
            sy = btn_sy[i]
            if (btn_down[i] == 1)
            {
                sx = btn_px[i]
                sy = btn_py[i]
            }
            draw_sprite_part_ext(sheet_spr, 0, sx, sy,
                btn_sw[i], btn_sh[i],
                cx - bw / 2, cy - bh / 2,
                bw / btn_sw[i], bh / btn_sh[i], c_white, a)

            ts = bw / btn_sw[i]
            draw_sprite_part_ext(sheet_spr, 0,
                joy_sx, joy_sy, joy_sw, joy_sh,
                cx + joy_ox - joy_sw * ts / 2,
                cy + joy_oy - joy_sh * ts / 2,
                ts, ts, c_white, a)
        }
        else
        {
            sx = btn_sx[i]
            sy = btn_sy[i]
            if (btn_down[i] == 1)
            {
                sx = btn_px[i]
                sy = btn_py[i]
            }
            draw_sprite_part_ext(sheet_spr, 0, sx, sy,
                btn_sw[i], btn_sh[i],
                cx - bw / 2, cy - bh / 2,
                bw / btn_sw[i], bh / btn_sh[i], c_white, a)

            // Floating joystick retains its original small moving ball.
            if (btn_mode[i] == 3)
            {
                ts = bw / btn_sw[i]
                tsx = joy_sx
                tsy = joy_sy
                if (btn_down[i] == 1)
                {
                    tsx = joy_px
                    tsy = joy_py
                }
                draw_sprite_part_ext(sheet_spr, 0, tsx, tsy,
                    joy_sw, joy_sh,
                    cx + joy_ox - joy_sw * ts / 2,
                    cy + joy_oy - joy_sh * ts / 2,
                    ts, ts, c_white, a)
            }
        }
    }
    else
    {
        draw_set_alpha(a)
        draw_set_color(c_dkgray)
        draw_rectangle(cx - bw / 2, cy - bh / 2,
            cx + bw / 2, cy + bh / 2, false)
    }
}
draw_set_alpha(1)
draw_set_color(c_white)
draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_text(gw * 0.06, gh * 0.02, "FPS: " + string(fps))
