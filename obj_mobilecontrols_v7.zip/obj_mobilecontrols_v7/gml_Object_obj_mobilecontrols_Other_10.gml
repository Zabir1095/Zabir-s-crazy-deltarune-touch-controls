for (i = 0; i < btn_count; i++)
{
    if (btn_mode[i] == 0)
    {
        if (btn_down[i] == 1 || btn_was[i] == 1)
            keyboard_key_release(btn_key[i])
        btn_down[i] = 0
        btn_was[i] = 0
    }
}
if (joy_l == 1)
    keyboard_key_release(37)
if (joy_r == 1)
    keyboard_key_release(39)
if (joy_u == 1)
    keyboard_key_release(38)
if (joy_d == 1)
    keyboard_key_release(40)
joy_l = 0
joy_r = 0
joy_u = 0
joy_d = 0
joy_dev = -1
joy_ox = 0
joy_oy = 0
