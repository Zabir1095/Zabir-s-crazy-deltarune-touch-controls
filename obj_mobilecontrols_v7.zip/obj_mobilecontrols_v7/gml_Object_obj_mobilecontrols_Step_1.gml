gw = display_get_gui_width()
gh = display_get_gui_height()
for (i = 0; i < btn_count; i++)
{
    btn_was[i] = btn_down[i]
    btn_down[i] = 0
    btn_show[i] = ((btn_vis[i] & (1 << ctrl_mode)) != 0)
    if (btn_edit_only[i] == 1 && edit_mode == 0)
        btn_show[i] = 0
}
joy_seen = 0
nl = 0
nr = 0
nu = 0
nd = 0
for (d = 0; d < max_touches; d++)
{
    if device_mouse_check_button(d, mb_left)
    {
        tx = device_mouse_x_to_gui(d)
        ty = device_mouse_y_to_gui(d)
        if (edit_mode == 1 && drag_dev == -1)
        {
            for (i = 0; i < btn_count; i++)
            {
                if (btn_show[i] == 1 && !(btn_mode[i] == 2 && btn_key[i] == 4) && !(btn_mode[i] == 3 && ctrl_mode == 3))
                {
                    bw = btn_w[i] * gw
                    bh = bw * btn_sh[i] / btn_sw[i]
                    if (abs(tx - btn_nx[i] * gw) <= bw / 2 && abs(ty - btn_ny[i] * gh) <= bh / 2)
                    {
                        drag_btn = i
                        drag_dev = d
                    }
                }
            }
        }
        if (drag_dev == d && drag_btn != -1)
        {
            btn_nx[drag_btn] = clamp(tx / gw, 0.02, 0.98)
            btn_ny[drag_btn] = clamp(ty / gh, 0.02, 0.98)
        }
        else
        {
            joy_here = 0
            if (edit_mode == 0 && (ctrl_mode == 2 || ctrl_mode == 3))
            {
                jr = btn_w[14] * gw / 2
                jcx = btn_nx[14] * gw
                jcy = btn_ny[14] * gh
                if (ctrl_mode == 3)
                {
                    jcx = dyn_x
                    jcy = dyn_y
                }
                claim = 0
                if (joy_dev == d)
                    claim = 1
                if (joy_dev == -1 && ctrl_mode == 2)
                {
                    if (point_distance(tx, ty, jcx, jcy) <= jr * 1.2)
                        claim = 1
                }
                if (joy_dev == -1 && ctrl_mode == 3 && tx < gw * 0.5)
                {
                    over = 0
                    for (i = 0; i < btn_count; i++)
                    {
                        if (btn_show[i] == 1 && btn_mode[i] != 3)
                        {
                            bw = btn_w[i] * gw
                            bh = bw * btn_sh[i] / btn_sw[i]
                            if (abs(tx - btn_nx[i] * gw) <= bw / 2 && abs(ty - btn_ny[i] * gh) <= bh / 2)
                                over = 1
                        }
                    }
                    if (over == 0)
                    {
                        claim = 1
                        dyn_x = tx
                        dyn_y = ty
                        jcx = tx
                        jcy = ty
                    }
                }
                if (claim == 1)
                {
                    joy_dev = d
                    joy_seen = 1
                    joy_here = 1
                    rx = tx - jcx
                    ry = ty - jcy
                    rl = point_distance(0, 0, rx, ry)
                    if (rl > jr * 0.25)
                    {
                        nl = (rx / rl < -0.38)
                        nr = (rx / rl > 0.38)
                        nu = (ry / rl < -0.38)
                        nd = (ry / rl > 0.38)
                    }
                    // fixed joystick: stick stays inside the base; floating joystick: stick can reach the ring edge
                    mxd = jr
                    if (ctrl_mode == 2)
                        mxd = jr * 0.35
                    if (rl > mxd)
                    {
                        rx = rx * mxd / rl
                        ry = ry * mxd / rl
                    }
                    joy_ox = rx
                    joy_oy = ry
                }
            }
            if (joy_here == 0)
            {
                for (i = 0; i < btn_count; i++)
                {
                    if (btn_show[i] == 0 || btn_mode[i] == 3)
                        continue
                    bw = btn_w[i] * gw
                    bh = bw * btn_sh[i] / btn_sw[i]
                    if (abs(tx - btn_nx[i] * gw) <= bw / 2 && abs(ty - btn_ny[i] * gh) <= bh / 2)
                        btn_down[i] = 1
                }
            }
        }
    }
    else if (drag_dev == d)
    {
        drag_dev = -1
        drag_btn = -1
    }
}
if (joy_dev != -1 && joy_seen == 0)
{
    joy_dev = -1
    joy_ox = 0
    joy_oy = 0
}
btn_down[14] = (joy_dev != -1)
if (nl != joy_l)
{
    if (nl == 1)
        keyboard_key_press(37)
    else
        keyboard_key_release(37)
}
if (nr != joy_r)
{
    if (nr == 1)
        keyboard_key_press(39)
    else
        keyboard_key_release(39)
}
if (nu != joy_u)
{
    if (nu == 1)
        keyboard_key_press(38)
    else
        keyboard_key_release(38)
}
if (nd != joy_d)
{
    if (nd == 1)
        keyboard_key_press(40)
    else
        keyboard_key_release(40)
}
joy_l = nl
joy_r = nr
joy_u = nu
joy_d = nd
for (i = 0; i < btn_count; i++)
{
    pressed = (btn_down[i] == 1 && btn_was[i] == 0)
    released = (btn_down[i] == 0 && btn_was[i] == 1)
    if (btn_mode[i] == 0 && edit_mode == 0)
    {
        if (pressed)
            keyboard_key_press(btn_key[i])
        if (released)
            keyboard_key_release(btn_key[i])
    }
    if (btn_mode[i] == 1 && edit_mode == 0 && pressed)
    {
        keyboard_key_press(btn_key[i])
        keyboard_key_release(btn_key[i])
    }
    if (btn_mode[i] == 2 && pressed)
    {
        act = btn_key[i]
        if (act == 8 && edit_mode == 0)
            room_speed = clamp(room_speed + 10, 10, 240)
        if (act == 9 && edit_mode == 0)
            room_speed = clamp(room_speed - 10, 10, 240)
        if (act == 4)
        {
            edit_mode = !edit_mode
            event_user(0)
        }
        if (act == 7 && edit_mode == 0)
        {
            // cycle: empty -> arrows -> joystick -> floating joystick -> empty
            old_mode = ctrl_mode
            event_user(0)
            ctrl_mode = (ctrl_mode + 1) mod 4
            if ((old_mode >= 2) != (ctrl_mode >= 2))
            {
                for (j = 4; j <= 6; j++)
                {
                    t = btn_nx[j]
                    btn_nx[j] = btn_ax[j]
                    btn_ax[j] = t
                    t = btn_ny[j]
                    btn_ny[j] = btn_ay[j]
                    btn_ay[j] = t
                }
            }
        }
        if (act == 5)
        {
            if (ctrl_mode >= 2)
            {
                for (j = 4; j <= 6; j++)
                {
                    t = btn_nx[j]
                    btn_nx[j] = btn_ax[j]
                    btn_ax[j] = t
                    t = btn_ny[j]
                    btn_ny[j] = btn_ay[j]
                    btn_ay[j] = t
                }
            }
            ini_open("mobilecontrols.ini")
            for (j = 0; j < btn_count; j++)
            {
                ini_write_real("layout", string(j) + "x", btn_nx[j])
                ini_write_real("layout", string(j) + "y", btn_ny[j])
            }
            for (j = 4; j <= 6; j++)
            {
                ini_write_real("alt", string(j) + "x", btn_ax[j])
                ini_write_real("alt", string(j) + "y", btn_ay[j])
            }
            ini_write_real("settings", "mode", ctrl_mode)
            ini_close()
            if (ctrl_mode >= 2)
            {
                for (j = 4; j <= 6; j++)
                {
                    t = btn_nx[j]
                    btn_nx[j] = btn_ax[j]
                    btn_ax[j] = t
                    t = btn_ny[j]
                    btn_ny[j] = btn_ay[j]
                    btn_ay[j] = t
                }
            }
        }
        if (act == 6)
        {
            for (j = 0; j < btn_count; j++)
            {
                btn_nx[j] = btn_dx[j]
                btn_ny[j] = btn_dy[j]
            }
            for (j = 4; j <= 6; j++)
            {
                btn_ax[j] = btn_dax[j]
                btn_ay[j] = btn_day[j]
            }
            if (ctrl_mode >= 2)
            {
                for (j = 4; j <= 6; j++)
                {
                    t = btn_nx[j]
                    btn_nx[j] = btn_ax[j]
                    btn_ax[j] = t
                    t = btn_ny[j]
                    btn_ny[j] = btn_ay[j]
                    btn_ay[j] = t
                }
            }
        }
    }
}
